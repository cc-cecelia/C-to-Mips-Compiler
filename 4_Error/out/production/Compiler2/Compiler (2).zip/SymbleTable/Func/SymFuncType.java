package SymbleTable.Func;

public enum SymFuncType {
    VOID,
    INT
}
