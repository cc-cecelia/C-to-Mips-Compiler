package VirtualMachine;

public class VM {
    //TODO :哈哈 等我有时间再写这个解释器吧~

}
