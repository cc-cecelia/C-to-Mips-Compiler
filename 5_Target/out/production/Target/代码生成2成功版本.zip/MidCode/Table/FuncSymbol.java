package MidCode.Table;

import Fronted.ASTComponent.AST;
import MidCode.Value.Value;
import Target.Instructions.MipsCode;

import java.util.HashMap;
import java.util.List;

public class FuncSymbol extends Symbol{
    private int tableNumber;
    private VarSymbol retVal;
    private int stackSize;// 局部变量 + 中间变量

    private HashMap<FuncSymbol,Integer> extraParamAddr;
    public FuncSymbol(AST ASTComponent, String midName, MidType type) {
        super(ASTComponent, midName, type);
    }

    public void setTableNumber(int tableNumber) {
        this.tableNumber = tableNumber;
    }

    public void setStackSize(int stackSize) {
        this.stackSize = stackSize;
    }

    public int getStackSize() {
        return stackSize;
    }

    public void setRealParamsStack() {
        // TODO:不知道要不要传入实参
    }

    public void setRetVal(VarSymbol retVal) {
        this.retVal = retVal;
    }

    public VarSymbol getRetVal() {
        return retVal;
    }

    @Override
    public String toString() {
        return getMidName();
    }

    @Override
    public Value clone() {
        FuncSymbol cloned = new FuncSymbol(getASTComponent(),getMidName(),getSymbolType());
        cloned.tableNumber = this.tableNumber;
        return cloned;
    }

    public List<MipsCode> toMipsCode() {
        return null;
    }
}
