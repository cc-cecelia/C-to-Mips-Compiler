import Fronted.Error.ErrorHandler;
import Fronted.Lexer.Lexer;
import Fronted.Parser.Parser;
import Fronted.Parser.SymbleTable.TablesController;
import IO.Output;
import MidCode.MidGenerator;
import MidCode.IRModule;
import Target.Assembler;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Compiler {
    public static void main(String[] args) throws IOException {
        Lexer lexer = Lexer.getInstance();
        Parser parser = Parser.getInstance();
        TablesController controller = TablesController.getInstance();
        ErrorHandler errorHandler = ErrorHandler.getInstance();
        errorHandler.controller = controller;
        controller.handler = errorHandler;
        parser.setLexer(lexer);
        parser.setController(controller);
        parser.setErrorHandler(errorHandler);
        try {
            lexer.src = new String(Files.readAllBytes(Paths.get("testfile.txt")));
            //lexer.src = new String(Files.readAllBytes(Paths.get("D:\\C_Compiler\\Target\\辅助测试\\A\\testfile9.txt")));
        } catch (IOException e) {
            System.out.println("no such file!");
        }
        lexer.analysis();
        parser.parseProgram();
        MidGenerator.CompUnit = parser.getCompUnit();
        MidGenerator.generateMidCode();
        //parser.print();
        IRModule.print();
        Assembler.generateMipsCode();
        Assembler.print();
        Output.close();

        // lexer.print(); LAB1-Fronted.Lexer
        // parser.print(); LAB2-Fronted.parser
        // errorHandler.print(); LAB3-Fronted.error
    }
}