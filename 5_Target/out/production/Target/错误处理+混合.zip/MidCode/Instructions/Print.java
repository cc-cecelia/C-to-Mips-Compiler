package MidCode.Instructions;

public abstract class Print extends Instruction{
}
