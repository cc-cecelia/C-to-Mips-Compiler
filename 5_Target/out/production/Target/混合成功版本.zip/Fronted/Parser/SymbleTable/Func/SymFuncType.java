package Fronted.Parser.SymbleTable.Func;

public enum SymFuncType {
    VOID,
    INT
}
